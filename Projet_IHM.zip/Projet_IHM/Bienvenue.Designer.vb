﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Bienvenue
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.QuitBtn = New System.Windows.Forms.Button()
        Me.createImgButton = New System.Windows.Forms.Button()
        Me.helpbtn = New System.Windows.Forms.Button()
        Me.openimgbtn = New System.Windows.Forms.Button()
        Me.title = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'QuitBtn
        '
        Me.QuitBtn.Location = New System.Drawing.Point(34, 377)
        Me.QuitBtn.Name = "QuitBtn"
        Me.QuitBtn.Size = New System.Drawing.Size(163, 49)
        Me.QuitBtn.TabIndex = 0
        Me.QuitBtn.Text = "Quitter"
        Me.QuitBtn.UseVisualStyleBackColor = True
        '
        'createImgButton
        '
        Me.createImgButton.Location = New System.Drawing.Point(246, 234)
        Me.createImgButton.Name = "createImgButton"
        Me.createImgButton.Size = New System.Drawing.Size(276, 47)
        Me.createImgButton.TabIndex = 1
        Me.createImgButton.Text = "Créer une nouvelle image"
        Me.createImgButton.UseVisualStyleBackColor = True
        '
        'helpbtn
        '
        Me.helpbtn.Location = New System.Drawing.Point(246, 169)
        Me.helpbtn.Name = "helpbtn"
        Me.helpbtn.Size = New System.Drawing.Size(276, 47)
        Me.helpbtn.TabIndex = 2
        Me.helpbtn.Text = "Aide"
        Me.helpbtn.UseVisualStyleBackColor = True
        '
        'openimgbtn
        '
        Me.openimgbtn.Location = New System.Drawing.Point(246, 298)
        Me.openimgbtn.Name = "openimgbtn"
        Me.openimgbtn.Size = New System.Drawing.Size(276, 47)
        Me.openimgbtn.TabIndex = 3
        Me.openimgbtn.TabStop = False
        Me.openimgbtn.Text = "Ouvrir une ancienne image"
        Me.openimgbtn.UseVisualStyleBackColor = True
        '
        'title
        '
        Me.title.AutoSize = True
        Me.title.Location = New System.Drawing.Point(243, 126)
        Me.title.Name = "title"
        Me.title.Size = New System.Drawing.Size(279, 13)
        Me.title.TabIndex = 4
        Me.title.Text = "Explication générale du logiciel de reconnaissance faciale"
        '
        'Bienvenue
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.title)
        Me.Controls.Add(Me.openimgbtn)
        Me.Controls.Add(Me.helpbtn)
        Me.Controls.Add(Me.createImgButton)
        Me.Controls.Add(Me.QuitBtn)
        Me.Name = "Bienvenue"
        Me.Text = "Bienvenue"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents QuitBtn As Button
    Friend WithEvents createImgButton As Button
    Friend WithEvents helpbtn As Button
    Friend WithEvents openimgbtn As Button
    Friend WithEvents title As Label
End Class
