﻿Public Class Aide
    Private Sub Aide_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub CloseHelpBtn_Click(sender As Object, e As EventArgs) Handles CloseHelpBtn.Click
        Me.Hide()
    End Sub

End Class