﻿Public Class Annotation
    Private Sub QuitBtn_Click(sender As Object, e As EventArgs) Handles QuitBtn.Click
        Me.Dispose()
        Bienvenue.Dispose()
    End Sub

    Private Sub HelpBttn_Click(sender As Object, e As EventArgs) Handles HelpBttn.Click
        Aide.Show()
    End Sub
End Class