﻿Public Class Résultat
    Private Sub QuitBtn_Click(sender As Object, e As EventArgs) Handles QuitBtn.Click
        Me.Dispose()
        Bienvenue.Dispose()
    End Sub

    Private Sub LoadNewPicturebtn_Click(sender As Object, e As EventArgs) Handles LoadNewPicturebtn.Click, returnbtn.Click
        Me.Hide()
        Annotation.Show()
    End Sub

    Private Sub helpbtn_Click(sender As Object, e As EventArgs) Handles helpbtn.Click
        Aide.Show()
    End Sub
End Class