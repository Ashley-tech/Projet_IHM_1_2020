﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Enregistrer
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SaveText = New System.Windows.Forms.Label()
        Me.SaveYesButton = New System.Windows.Forms.Button()
        Me.SaveNoButton = New System.Windows.Forms.Button()
        Me.SaveCancelButton = New System.Windows.Forms.Button()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.SuspendLayout()
        '
        'SaveText
        '
        Me.SaveText.AutoSize = True
        Me.SaveText.Location = New System.Drawing.Point(26, 26)
        Me.SaveText.Name = "SaveText"
        Me.SaveText.Size = New System.Drawing.Size(247, 17)
        Me.SaveText.TabIndex = 0
        Me.SaveText.Text = "Voulez-vous enregistrer votre projet ?"
        '
        'SaveYesButton
        '
        Me.SaveYesButton.Location = New System.Drawing.Point(29, 91)
        Me.SaveYesButton.Name = "SaveYesButton"
        Me.SaveYesButton.Size = New System.Drawing.Size(168, 38)
        Me.SaveYesButton.TabIndex = 1
        Me.SaveYesButton.Text = "Enregistrer"
        Me.SaveYesButton.UseVisualStyleBackColor = True
        '
        'SaveNoButton
        '
        Me.SaveNoButton.Location = New System.Drawing.Point(232, 91)
        Me.SaveNoButton.Name = "SaveNoButton"
        Me.SaveNoButton.Size = New System.Drawing.Size(168, 38)
        Me.SaveNoButton.TabIndex = 2
        Me.SaveNoButton.Text = "Ne pas enregistrer"
        Me.SaveNoButton.UseVisualStyleBackColor = True
        '
        'SaveCancelButton
        '
        Me.SaveCancelButton.Location = New System.Drawing.Point(434, 91)
        Me.SaveCancelButton.Name = "SaveCancelButton"
        Me.SaveCancelButton.Size = New System.Drawing.Size(168, 38)
        Me.SaveCancelButton.TabIndex = 3
        Me.SaveCancelButton.Text = "Annuler"
        Me.SaveCancelButton.UseVisualStyleBackColor = True
        '
        'SaveFileDialog1
        '
        '
        'Enregistrer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(626, 154)
        Me.Controls.Add(Me.SaveCancelButton)
        Me.Controls.Add(Me.SaveNoButton)
        Me.Controls.Add(Me.SaveYesButton)
        Me.Controls.Add(Me.SaveText)
        Me.Name = "Enregistrer"
        Me.Text = "Enregistrer"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents SaveText As Label
    Friend WithEvents SaveYesButton As Button
    Friend WithEvents SaveNoButton As Button
    Friend WithEvents SaveCancelButton As Button
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
End Class
