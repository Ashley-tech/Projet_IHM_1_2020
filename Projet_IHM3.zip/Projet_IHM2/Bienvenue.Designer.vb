﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Bienvenue
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.QuitBtn = New System.Windows.Forms.Button()
        Me.createImgButton = New System.Windows.Forms.Button()
        Me.helpbtn = New System.Windows.Forms.Button()
        Me.openimgbtn = New System.Windows.Forms.Button()
        Me.title = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.OpenFileDialog2 = New System.Windows.Forms.OpenFileDialog()
        Me.SuspendLayout()
        '
        'QuitBtn
        '
        Me.QuitBtn.Location = New System.Drawing.Point(45, 464)
        Me.QuitBtn.Margin = New System.Windows.Forms.Padding(4)
        Me.QuitBtn.Name = "QuitBtn"
        Me.QuitBtn.Size = New System.Drawing.Size(217, 60)
        Me.QuitBtn.TabIndex = 0
        Me.QuitBtn.Text = "Quitter"
        Me.QuitBtn.UseVisualStyleBackColor = True
        '
        'createImgButton
        '
        Me.createImgButton.Location = New System.Drawing.Point(328, 288)
        Me.createImgButton.Margin = New System.Windows.Forms.Padding(4)
        Me.createImgButton.Name = "createImgButton"
        Me.createImgButton.Size = New System.Drawing.Size(368, 58)
        Me.createImgButton.TabIndex = 1
        Me.createImgButton.Text = "Créer une nouvelle image"
        Me.createImgButton.UseVisualStyleBackColor = True
        '
        'helpbtn
        '
        Me.helpbtn.Location = New System.Drawing.Point(328, 208)
        Me.helpbtn.Margin = New System.Windows.Forms.Padding(4)
        Me.helpbtn.Name = "helpbtn"
        Me.helpbtn.Size = New System.Drawing.Size(368, 58)
        Me.helpbtn.TabIndex = 2
        Me.helpbtn.Text = "Aide"
        Me.helpbtn.UseVisualStyleBackColor = True
        '
        'openimgbtn
        '
        Me.openimgbtn.Location = New System.Drawing.Point(328, 367)
        Me.openimgbtn.Margin = New System.Windows.Forms.Padding(4)
        Me.openimgbtn.Name = "openimgbtn"
        Me.openimgbtn.Size = New System.Drawing.Size(368, 58)
        Me.openimgbtn.TabIndex = 3
        Me.openimgbtn.TabStop = False
        Me.openimgbtn.Text = "Ouvrir une ancienne image"
        Me.openimgbtn.UseVisualStyleBackColor = True
        '
        'title
        '
        Me.title.AutoSize = True
        Me.title.Location = New System.Drawing.Point(324, 155)
        Me.title.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.title.Name = "title"
        Me.title.Size = New System.Drawing.Size(371, 17)
        Me.title.TabIndex = 4
        Me.title.Text = "Explication générale du logiciel de reconnaissance faciale"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'OpenFileDialog2
        '
        Me.OpenFileDialog2.FileName = "OpenFileDialog2"
        '
        'Bienvenue
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1067, 554)
        Me.Controls.Add(Me.title)
        Me.Controls.Add(Me.openimgbtn)
        Me.Controls.Add(Me.helpbtn)
        Me.Controls.Add(Me.createImgButton)
        Me.Controls.Add(Me.QuitBtn)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Bienvenue"
        Me.Text = "Bienvenue"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents QuitBtn As Button
    Friend WithEvents createImgButton As Button
    Friend WithEvents helpbtn As Button
    Friend WithEvents openimgbtn As Button
    Friend WithEvents title As Label
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents OpenFileDialog2 As OpenFileDialog
End Class
