﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Résultat
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.QuitBtn = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.returnbtn = New System.Windows.Forms.Button()
        Me.LoadNewPicturebtn = New System.Windows.Forms.Button()
        Me.FindPeople = New System.Windows.Forms.Label()
        Me.helpbtn = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'QuitBtn
        '
        Me.QuitBtn.Location = New System.Drawing.Point(29, 448)
        Me.QuitBtn.Name = "QuitBtn"
        Me.QuitBtn.Size = New System.Drawing.Size(73, 27)
        Me.QuitBtn.TabIndex = 1
        Me.QuitBtn.Text = "Quitter"
        Me.QuitBtn.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(435, 22)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(319, 287)
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(29, 22)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(347, 286)
        Me.PictureBox2.TabIndex = 3
        Me.PictureBox2.TabStop = False
        '
        'returnbtn
        '
        Me.returnbtn.Location = New System.Drawing.Point(261, 416)
        Me.returnbtn.Name = "returnbtn"
        Me.returnbtn.Size = New System.Drawing.Size(271, 28)
        Me.returnbtn.TabIndex = 4
        Me.returnbtn.Text = "Retour aux annotations"
        Me.returnbtn.UseVisualStyleBackColor = True
        '
        'LoadNewPicturebtn
        '
        Me.LoadNewPicturebtn.Location = New System.Drawing.Point(261, 382)
        Me.LoadNewPicturebtn.Name = "LoadNewPicturebtn"
        Me.LoadNewPicturebtn.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.LoadNewPicturebtn.Size = New System.Drawing.Size(271, 28)
        Me.LoadNewPicturebtn.TabIndex = 5
        Me.LoadNewPicturebtn.Text = "Charger une nouvelle image"
        Me.LoadNewPicturebtn.UseVisualStyleBackColor = True
        '
        'FindPeople
        '
        Me.FindPeople.AutoSize = True
        Me.FindPeople.Location = New System.Drawing.Point(328, 323)
        Me.FindPeople.Name = "FindPeople"
        Me.FindPeople.Size = New System.Drawing.Size(133, 13)
        Me.FindPeople.TabIndex = 6
        Me.FindPeople.Text = "Voici la personne trouvée :"
        '
        'helpbtn
        '
        Me.helpbtn.Location = New System.Drawing.Point(652, 450)
        Me.helpbtn.Name = "helpbtn"
        Me.helpbtn.Size = New System.Drawing.Size(101, 24)
        Me.helpbtn.TabIndex = 7
        Me.helpbtn.Text = "Aide"
        Me.helpbtn.UseVisualStyleBackColor = True
        '
        'Résultat
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 487)
        Me.Controls.Add(Me.helpbtn)
        Me.Controls.Add(Me.FindPeople)
        Me.Controls.Add(Me.LoadNewPicturebtn)
        Me.Controls.Add(Me.returnbtn)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.QuitBtn)
        Me.Name = "Résultat"
        Me.Text = "Résultat"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents QuitBtn As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents returnbtn As Button
    Friend WithEvents LoadNewPicturebtn As Button
    Friend WithEvents FindPeople As Label
    Friend WithEvents helpbtn As Button
End Class
