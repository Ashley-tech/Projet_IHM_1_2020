﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Annotation
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.QuitBtn = New System.Windows.Forms.Button()
        Me.ZoomInOut = New System.Windows.Forms.Button()
        Me.ZoomOutBtn = New System.Windows.Forms.Button()
        Me.SaveButton = New System.Windows.Forms.Button()
        Me.HelpBttn = New System.Windows.Forms.Button()
        Me.LoadNewImg = New System.Windows.Forms.Button()
        Me.CorresBtn = New System.Windows.Forms.Button()
        Me.EyeCursor = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.MentonBtn = New System.Windows.Forms.Button()
        Me.NezBtn = New System.Windows.Forms.Button()
        Me.BVBUTTON = New System.Windows.Forms.Button()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(31, 26)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(734, 532)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'QuitBtn
        '
        Me.QuitBtn.Location = New System.Drawing.Point(807, 583)
        Me.QuitBtn.Margin = New System.Windows.Forms.Padding(4)
        Me.QuitBtn.Name = "QuitBtn"
        Me.QuitBtn.Size = New System.Drawing.Size(275, 48)
        Me.QuitBtn.TabIndex = 2
        Me.QuitBtn.Text = "Quitter"
        Me.QuitBtn.UseVisualStyleBackColor = True
        '
        'ZoomInOut
        '
        Me.ZoomInOut.Location = New System.Drawing.Point(31, 566)
        Me.ZoomInOut.Margin = New System.Windows.Forms.Padding(4)
        Me.ZoomInOut.Name = "ZoomInOut"
        Me.ZoomInOut.Size = New System.Drawing.Size(79, 52)
        Me.ZoomInOut.TabIndex = 3
        Me.ZoomInOut.Text = "+"
        Me.ZoomInOut.UseVisualStyleBackColor = True
        '
        'ZoomOutBtn
        '
        Me.ZoomOutBtn.Location = New System.Drawing.Point(142, 566)
        Me.ZoomOutBtn.Margin = New System.Windows.Forms.Padding(4)
        Me.ZoomOutBtn.Name = "ZoomOutBtn"
        Me.ZoomOutBtn.Size = New System.Drawing.Size(79, 52)
        Me.ZoomOutBtn.TabIndex = 4
        Me.ZoomOutBtn.Text = "-"
        Me.ZoomOutBtn.UseVisualStyleBackColor = True
        '
        'SaveButton
        '
        Me.SaveButton.Location = New System.Drawing.Point(807, 446)
        Me.SaveButton.Margin = New System.Windows.Forms.Padding(4)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(271, 46)
        Me.SaveButton.TabIndex = 5
        Me.SaveButton.Text = "Enregistrer les annotations"
        Me.SaveButton.UseVisualStyleBackColor = True
        '
        'HelpBttn
        '
        Me.HelpBttn.Location = New System.Drawing.Point(806, 378)
        Me.HelpBttn.Margin = New System.Windows.Forms.Padding(4)
        Me.HelpBttn.Name = "HelpBttn"
        Me.HelpBttn.Size = New System.Drawing.Size(271, 46)
        Me.HelpBttn.TabIndex = 6
        Me.HelpBttn.Text = "Aide"
        Me.HelpBttn.UseVisualStyleBackColor = True
        '
        'LoadNewImg
        '
        Me.LoadNewImg.Location = New System.Drawing.Point(804, 2)
        Me.LoadNewImg.Margin = New System.Windows.Forms.Padding(4)
        Me.LoadNewImg.Name = "LoadNewImg"
        Me.LoadNewImg.Size = New System.Drawing.Size(269, 42)
        Me.LoadNewImg.TabIndex = 7
        Me.LoadNewImg.Text = "Charger une nouvelle image"
        Me.LoadNewImg.UseVisualStyleBackColor = True
        '
        'CorresBtn
        '
        Me.CorresBtn.Location = New System.Drawing.Point(807, 514)
        Me.CorresBtn.Name = "CorresBtn"
        Me.CorresBtn.Size = New System.Drawing.Size(270, 44)
        Me.CorresBtn.TabIndex = 8
        Me.CorresBtn.Text = "Correspondance"
        Me.CorresBtn.UseVisualStyleBackColor = True
        '
        'EyeCursor
        '
        Me.EyeCursor.Location = New System.Drawing.Point(801, 62)
        Me.EyeCursor.Name = "EyeCursor"
        Me.EyeCursor.Size = New System.Drawing.Size(273, 45)
        Me.EyeCursor.TabIndex = 9
        Me.EyeCursor.Text = "Oeil"
        Me.EyeCursor.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(807, 251)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(267, 45)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "Bouche"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'MentonBtn
        '
        Me.MentonBtn.Location = New System.Drawing.Point(808, 316)
        Me.MentonBtn.Name = "MentonBtn"
        Me.MentonBtn.Size = New System.Drawing.Size(270, 44)
        Me.MentonBtn.TabIndex = 11
        Me.MentonBtn.Text = "Menton"
        Me.MentonBtn.UseVisualStyleBackColor = True
        '
        'NezBtn
        '
        Me.NezBtn.Location = New System.Drawing.Point(807, 189)
        Me.NezBtn.Name = "NezBtn"
        Me.NezBtn.Size = New System.Drawing.Size(270, 44)
        Me.NezBtn.TabIndex = 12
        Me.NezBtn.Text = "Nez"
        Me.NezBtn.UseVisualStyleBackColor = True
        '
        'BVBUTTON
        '
        Me.BVBUTTON.Location = New System.Drawing.Point(804, 118)
        Me.BVBUTTON.Name = "BVBUTTON"
        Me.BVBUTTON.Size = New System.Drawing.Size(270, 44)
        Me.BVBUTTON.TabIndex = 13
        Me.BVBUTTON.Text = "BV"
        Me.BVBUTTON.UseVisualStyleBackColor = True
        '
        'SaveFileDialog1
        '
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Annotation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1117, 644)
        Me.Controls.Add(Me.BVBUTTON)
        Me.Controls.Add(Me.NezBtn)
        Me.Controls.Add(Me.MentonBtn)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.EyeCursor)
        Me.Controls.Add(Me.CorresBtn)
        Me.Controls.Add(Me.LoadNewImg)
        Me.Controls.Add(Me.HelpBttn)
        Me.Controls.Add(Me.SaveButton)
        Me.Controls.Add(Me.ZoomOutBtn)
        Me.Controls.Add(Me.ZoomInOut)
        Me.Controls.Add(Me.QuitBtn)
        Me.Controls.Add(Me.PictureBox1)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Annotation"
        Me.Text = "Annotation"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents QuitBtn As Button
    Friend WithEvents ZoomInOut As Button
    Friend WithEvents ZoomOutBtn As Button
    Friend WithEvents SaveButton As Button
    Friend WithEvents HelpBttn As Button
    Friend WithEvents LoadNewImg As Button
    Friend WithEvents CorresBtn As Button
    Friend WithEvents EyeCursor As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents MentonBtn As Button
    Friend WithEvents NezBtn As Button
    Friend WithEvents BVBUTTON As Button
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
End Class
