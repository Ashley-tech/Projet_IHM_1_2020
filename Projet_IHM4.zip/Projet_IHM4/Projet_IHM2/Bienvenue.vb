﻿'RAKOTOARISOA Ashley et RAHARINOSY Brice TP2A
' 24/05/2020
' PROJET IHM

Public Class Bienvenue
    Public Shared strFileName As String

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles QuitBtn.Click
        Me.Dispose()
    End Sub


    Private Sub createImgButton_Click(sender As Object, e As EventArgs) Handles createImgButton.Click
        Dim fd As OpenFileDialog = New OpenFileDialog()

        fd.Title = "Open File Dialog"
        fd.InitialDirectory = "C:\"
        fd.Filter = "Fichier PNG (*.png*)|*png.*|Fichier JPG (*.jpg*)|*jpg.*|Fichier JPEG (*.jpeg*)|*jpeg.*|All files (*.*)|*.*"
        fd.FilterIndex = 2
        fd.RestoreDirectory = True

        If fd.ShowDialog() = DialogResult.OK Then
            strFileName = fd.FileName
            Me.Hide()
            Annotation.Show()
            Annotation.PictureBox1.Image = Image.FromFile(Bienvenue.strFileName)
        End If
    End Sub

    'modify the above

    Private Sub helpbtn_Click(sender As Object, e As EventArgs) Handles helpbtn.Click
        Aide.Show()
    End Sub

    Public Sub openimgbtn_Click(sender As Object, e As EventArgs) Handles openimgbtn.Click
        Dim fd As OpenFileDialog = New OpenFileDialog()

        fd.Title = "Open File Dialog"
        fd.InitialDirectory = "C:\"
        fd.Filter = "Fichier CSV (*.csv*)|*csv.*|All files (*.*)|*.*"
        fd.FilterIndex = 2
        fd.RestoreDirectory = True

        If fd.ShowDialog() = DialogResult.OK Then
            strFileName = fd.FileName
            Me.Hide()
            Annotation.Show()
            ' Annotation.PictureBox1.Image = Image.FromFile(Bienvenue.strFileName)
            Annotation.imagez = Image.FromFile(Bienvenue.strFileName)
            Annotation.gfx.DrawImage(Annotation.imagez, Annotation.testPoint)
            Annotation.PictureBox1.Image = Annotation.pic

        End If
    End Sub
End Class