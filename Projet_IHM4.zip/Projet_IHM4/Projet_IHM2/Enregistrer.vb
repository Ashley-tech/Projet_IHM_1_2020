﻿Public Class Enregistrer
    Private Sub SaveNoButton_Click(sender As Object, e As EventArgs) Handles SaveNoButton.Click
        Me.Dispose()
        Bienvenue.Dispose()
    End Sub

    Private Sub SaveCancelButton_Click(sender As Object, e As EventArgs) Handles SaveCancelButton.Click
        Me.Hide()
    End Sub

    Private Sub SaveYesButton_Click(sender As Object, e As EventArgs) Handles SaveYesButton.Click
        SaveFileDialog1.ShowDialog()
        SaveFileDialog1.Title = "Open File Dialog"
        SaveFileDialog1.InitialDirectory = "C:\Users\Ashley\Documents\"
        SaveFileDialog1.Filter = "All files (*.*)|*.*|CSV (*csv.*)|*csv.*"
        SaveFileDialog1.FilterIndex = 2
        SaveFileDialog1.RestoreDirectory = True
    End Sub

    Private Sub SaveFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog1.FileOk

    End Sub
End Class