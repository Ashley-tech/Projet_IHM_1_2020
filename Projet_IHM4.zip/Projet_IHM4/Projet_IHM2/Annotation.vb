﻿'RAKOTOARISOA Ashley et RAHARINOSY Brice TP2A
' 24/05/2020
' PROJET IHM

Public Class Annotation
    Dim modif As Boolean = True
    Dim save1 As SaveFileDialog
    Dim Dd As Annotation
    Public Shared strFileName As String
    Dim wl As Bienvenue
    Dim OpenFile As OpenFileDialog
    Dim photo As PictureBox
    'Dim brush As SolidBrush
    Dim redPen As New Pen(Brushes.Red, 4)

    'Public Shared img As New Image(Of Bgr, Byte)(OpenFileDialog1.FileName.ToString)
    Public Shared pic As New Bitmap(1600, 1060) '= img.Bitmap()
    Public Shared gfx As Graphics = Graphics.FromImage(pic)
    Public Shared imagez As Image
    Public Shared testPoint As Point = New Point(0, 0)
    Public Shared testPoint2 As Point = New Point(1000, 500)
    Public Shared testPoint3 As Point = New Point(1200, 300)


    Private Sub QuitBtn_Click(sender As Object, e As EventArgs) Handles QuitBtn.Click
        If modif = True Then
            Enregistrer.Show()
        End If
        If modif = False Then
            Me.Dispose()
            Bienvenue.Dispose()
        End If
    End Sub

    Private Sub HelpBttn_Click(sender As Object, e As EventArgs) Handles HelpBttn.Click
        Aide.Show()
    End Sub

    Private Sub PictureBox1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseMove
        'Get the X and Y ratio each time an image is loaded (If the images are different sizes)
        'Otherwise if the images are all the same size then you only need to calculate them once.
        Dim RatioX As Double = PictureBox1.Image.Width / PictureBox1.ClientSize.Width
        Dim RatioY As Double = PictureBox1.Image.Height / PictureBox1.ClientSize.Height
        Dim mp As New Point(CInt(e.X * RatioX), CInt(e.Y * RatioY))
        Me.Text = mp.ToString

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseDown, PictureBox1.Click
        Dim aPoint = New Point(e.X, e.Y)
        Dim bPoint = New Point(e.X - 20, e.Y)
        Dim cPoint = New Point(e.X + 20, e.Y)
        Dim dPoint = New Point(e.X, e.Y - 20)
        Dim ePoint = New Point(e.X, e.Y + 20)
        gfx.DrawLine(redPen, testPoint2, testPoint3)
        gfx.DrawLine(redPen, dPoint, ePoint)
    End Sub

    Private Sub LoadNewImg_Click(sender As Object, e As EventArgs) Handles LoadNewImg.Click
        Dim fd As OpenFileDialog = New OpenFileDialog()

        fd.Title = "Choisir une photo PNG, JPG ou JPEG"
        fd.InitialDirectory = "C:\"
        fd.Filter = "All files (*.*)|*.*"
        fd.FilterIndex = 2
        fd.RestoreDirectory = True

        If fd.ShowDialog() = DialogResult.OK Then
            strFileName = fd.FileName
            Me.PictureBox1.Image = Image.FromFile(Bienvenue.strFileName)
        End If
        Me.PictureBox1.Image = Image.FromFile(Bienvenue.strFileName)
    End Sub

    Private Sub SaveButton_Click(sender As Object, e As EventArgs) Handles SaveButton.Click
        SaveFileDialog1.ShowDialog()
        SaveFileDialog1.Title = "Open File Dialog"
        SaveFileDialog1.InitialDirectory = "C:\Users\Ashley\Documents\"
        SaveFileDialog1.Filter = "All files (*.*)|*.*|CSV (*csv.*)|*csv.*"
        SaveFileDialog1.FilterIndex = 2
        SaveFileDialog1.RestoreDirectory = True

    End Sub

    Private Sub SaveFileDialog1_FileOk(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog1.FileOk

    End Sub

    Private Sub EyeCursor_Click(sender As Object, e As EventArgs) Handles EyeCursor.Click

    End Sub

End Class