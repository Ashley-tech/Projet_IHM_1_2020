﻿'RAKOTOARISOA Ashley et RAHARINOSY Brice TP2A
' 24/05/2020
' PROJET IHM

Public Class Bienvenue
    Public Shared strFileName As String

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles QuitBtn.Click
        Me.Dispose()
    End Sub


    Private Sub createImgButton_Click(sender As Object, e As EventArgs) Handles createImgButton.Click, openimgbtn.Click
        Dim fd As OpenFileDialog = New OpenFileDialog()

        fd.Title = "Open File Dialog"
        fd.InitialDirectory = "C:\"
        fd.Filter = "All files (*.*)|*.*|All files (*.*)|*.*"
        fd.FilterIndex = 2
        fd.RestoreDirectory = True

        If fd.ShowDialog() = DialogResult.OK Then
            strFileName = fd.FileName
        End If

        Me.Hide()
        Annotation.Show()
        Annotation.PictureBox1.Image = Image.FromFile(Bienvenue.strFileName)


    End Sub

    'modify the above

    Private Sub helpbtn_Click(sender As Object, e As EventArgs) Handles helpbtn.Click
        Aide.Show()
    End Sub

End Class