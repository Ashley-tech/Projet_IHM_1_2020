﻿'RAKOTOARISOA Ashley et RAHARINOSY Brice TP2A
' 24/05/2020
' PROJET IHM

Public Class Annotation

    Private Sub QuitBtn_Click(sender As Object, e As EventArgs) Handles QuitBtn.Click
        Me.Dispose()
        Bienvenue.Dispose()
    End Sub

    Private Sub HelpBttn_Click(sender As Object, e As EventArgs) Handles HelpBttn.Click
        Aide.Show()
    End Sub

    Private Sub PictureBox1_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseMove
        'Get the X and Y ratio each time an image is loaded (If the images are different sizes)
        'Otherwise if the images are all the same size then you only need to calculate them once.
        Dim RatioX As Double = PictureBox1.Image.Width / PictureBox1.ClientSize.Width
        Dim RatioY As Double = PictureBox1.Image.Height / PictureBox1.ClientSize.Height
        Dim mp As New Point(CInt(e.X * RatioX), CInt(e.Y * RatioY))
        Me.Text = mp.ToString
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseDown
        Dim aPoint = New Point(e.X, e.Y)
    End Sub

End Class