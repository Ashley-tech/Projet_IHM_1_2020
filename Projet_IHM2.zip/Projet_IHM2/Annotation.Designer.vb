﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Annotation
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.QuitBtn = New System.Windows.Forms.Button()
        Me.ZoomInOut = New System.Windows.Forms.Button()
        Me.ZoomOutBtn = New System.Windows.Forms.Button()
        Me.SaveButton = New System.Windows.Forms.Button()
        Me.HelpBttn = New System.Windows.Forms.Button()
        Me.LoadNewImg = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(23, 21)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(427, 404)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'QuitBtn
        '
        Me.QuitBtn.Location = New System.Drawing.Point(462, 448)
        Me.QuitBtn.Name = "QuitBtn"
        Me.QuitBtn.Size = New System.Drawing.Size(206, 39)
        Me.QuitBtn.TabIndex = 2
        Me.QuitBtn.Text = "Quitter"
        Me.QuitBtn.UseVisualStyleBackColor = True
        '
        'ZoomInOut
        '
        Me.ZoomInOut.Location = New System.Drawing.Point(23, 445)
        Me.ZoomInOut.Name = "ZoomInOut"
        Me.ZoomInOut.Size = New System.Drawing.Size(59, 42)
        Me.ZoomInOut.TabIndex = 3
        Me.ZoomInOut.Text = "+"
        Me.ZoomInOut.UseVisualStyleBackColor = True
        '
        'ZoomOutBtn
        '
        Me.ZoomOutBtn.Location = New System.Drawing.Point(101, 445)
        Me.ZoomOutBtn.Name = "ZoomOutBtn"
        Me.ZoomOutBtn.Size = New System.Drawing.Size(59, 42)
        Me.ZoomOutBtn.TabIndex = 4
        Me.ZoomOutBtn.Text = "-"
        Me.ZoomOutBtn.UseVisualStyleBackColor = True
        '
        'SaveButton
        '
        Me.SaveButton.Location = New System.Drawing.Point(462, 388)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(203, 37)
        Me.SaveButton.TabIndex = 5
        Me.SaveButton.Text = "Enregistrer les annotations"
        Me.SaveButton.UseVisualStyleBackColor = True
        '
        'HelpBttn
        '
        Me.HelpBttn.Location = New System.Drawing.Point(462, 330)
        Me.HelpBttn.Name = "HelpBttn"
        Me.HelpBttn.Size = New System.Drawing.Size(203, 37)
        Me.HelpBttn.TabIndex = 6
        Me.HelpBttn.Text = "Aide"
        Me.HelpBttn.UseVisualStyleBackColor = True
        '
        'LoadNewImg
        '
        Me.LoadNewImg.Location = New System.Drawing.Point(466, 14)
        Me.LoadNewImg.Name = "LoadNewImg"
        Me.LoadNewImg.Size = New System.Drawing.Size(197, 34)
        Me.LoadNewImg.TabIndex = 7
        Me.LoadNewImg.Text = "Charger une nouvelle image"
        Me.LoadNewImg.UseVisualStyleBackColor = True
        '
        'Annotation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(680, 499)
        Me.Controls.Add(Me.LoadNewImg)
        Me.Controls.Add(Me.HelpBttn)
        Me.Controls.Add(Me.SaveButton)
        Me.Controls.Add(Me.ZoomOutBtn)
        Me.Controls.Add(Me.ZoomInOut)
        Me.Controls.Add(Me.QuitBtn)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Annotation"
        Me.Text = "Annotation"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents QuitBtn As Button
    Friend WithEvents ZoomInOut As Button
    Friend WithEvents ZoomOutBtn As Button
    Friend WithEvents SaveButton As Button
    Friend WithEvents HelpBttn As Button
    Friend WithEvents LoadNewImg As Button
End Class
